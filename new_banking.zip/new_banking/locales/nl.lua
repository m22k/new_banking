Locales['nl'] = {
    ['invalid_amount'] = 'Ongeldig Hoeveelheid',
    ['atm_blip'] = 'Geldautomaat',
    ['bank_blip'] = 'Bank',
    ['atm_open'] = 'Druk ~INPUT_PICKUP~ om uw account te openen ~b~',
    ['no_money'] = 'U heeft niet genoeg geld',
    ['recieved1'] = 'Je hebt geld ontvangen ',
    ['recieved2'] = 'Je hebt een hoeveelheid ontvangen van ',
    ['recieved3'] = ' euro',
    ['removed1'] = 'Betalingsbewijs ',
    ['removed2'] = 'Uw betaling van ',
    ['removed3'] = ' euro is doorgegeven'
}
