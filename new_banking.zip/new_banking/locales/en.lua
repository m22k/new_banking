Locales['en'] = {
    ['invalid_amount'] = 'Invalid Amount',
    ['atm_blip'] = 'ATM',
    ['bank_blip'] = 'Bank',
    ['atm_open'] = 'Paina ~INPUT_PICKUP~ avataksesi tilisi ~b~',
    ['no_money'] = 'Sinulla ei ole tarpeeksi rahaa',
    ['recieved1'] = 'Sinä sait rahaa ',
    ['recieved2'] = 'Sinä sait rahaa ',
    ['recieved3'] = ' dollars',
    ['removed1'] = 'Payment receipt ',
    ['removed2'] = 'Your payment of ',
    ['removed3'] = ' dollars is done'
}
